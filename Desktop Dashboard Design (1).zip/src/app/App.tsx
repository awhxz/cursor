import React, { useState, useMemo, useRef, useEffect } from "react";
import { Search, Check } from "lucide-react";
import { ChevronDown } from "lucide-react";

// ─── Types ────────────────────────────────────────────────────────────────────

type Priority = 1 | 2 | 3 | 4;
type Responsible = "Аня Г." | "Настя П." | "Саша Г." | "Таня К." | "Не назначен";

interface Task {
  ticket: string | null;
  name: string;
  client: string;
  direction: string;
  status: string;
  priority: Priority;
  time: string;
  comment: string;
  responsible: Responsible;
}

// ─── Option Lists ─────────────────────────────────────────────────────────────

const ALL_CLIENTS: string[] = [
  "Сбер", "Яндекс", "Озон", "ВТБ", "МТС",
  "Газпром", "МегаФон", "Тинькофф", "Внутренний", "Баги",
];
const ALL_DIRECTIONS: string[] = [
  "Маркетинг", "Аналитика продаж", "Операции", "Продукт", "BI",
  "Финансы", "Ценообразование", "Стратегия", "HR/People",
  "CX/Клиентский опыт", "Баг/недоработка",
];
const ALL_STATUSES: string[] = ["В работе", "Ожидание", "Согласование", "На паузе", "Готово"];
const ALL_RESPONSIBLES: Responsible[] = ["Аня Г.", "Настя П.", "Саша Г.", "Таня К.", "Не назначен"];

const DEFAULT_CLIENTS     = new Set(ALL_CLIENTS.filter(c => c !== "Баги"));
const DEFAULT_DIRECTIONS  = new Set(ALL_DIRECTIONS.filter(d => d !== "Баг/недоработка"));
const DEFAULT_STATUSES    = new Set(ALL_STATUSES);
const DEFAULT_RESPONSIBLES = new Set<string>(ALL_RESPONSIBLES);

// ─── Color Maps ───────────────────────────────────────────────────────────────

// Used only in filter dropdowns
const TAG_COLORS: Record<string, [string, string]> = {
  "Сбер":               ["#D1FAE5", "#065F46"],
  "Яндекс":             ["#FEF3C7", "#92400E"],
  "Озон":               ["#DBEAFE", "#1E40AF"],
  "ВТБ":                ["#E0E7FF", "#3730A3"],
  "МТС":                ["#FEE2E2", "#991B1B"],
  "Газпром":            ["#F0FDF4", "#166534"],
  "МегаФон":            ["#EDE9FE", "#5B21B6"],
  "Тинькофф":           ["#FEF9C3", "#713F12"],
  "Внутренний":         ["#F3F4F6", "#4B5563"],
  "Баги":               ["#FEE2E2", "#B91C1C"],
  "Маркетинг":          ["#FCE7F3", "#9D174D"],
  "Аналитика продаж":   ["#CFFAFE", "#155E75"],
  "Операции":           ["#FFEDD5", "#9A3412"],
  "Продукт":            ["#F3E8FF", "#6D28D9"],
  "BI":                 ["#CCFBF1", "#0F766E"],
  "Финансы":            ["#ECFCCB", "#365314"],
  "Ценообразование":    ["#FFE4E6", "#9F1239"],
  "Стратегия":          ["#E0F2FE", "#0369A1"],
  "HR/People":          ["#FDF4FF", "#7E22CE"],
  "CX/Клиентский опыт": ["#FFF1F2", "#BE123C"],
  "Баг/недоработка":    ["#FEE2E2", "#B91C1C"],
  "В работе":           ["#DBEAFE", "#1D4ED8"],
  "Ожидание":           ["#FEF3C7", "#B45309"],
  "Согласование":       ["#F3E8FF", "#7E22CE"],
  "На паузе":           ["#F1F5F9", "#64748B"],
  "Готово":             ["#DCFCE7", "#15803D"],
};

const PRIORITY_COLOR: Record<number, [string, string]> = {
  4: ["#DCFCE7", "#15803D"],
  3: ["#FEF9C3", "#B45309"],
  2: ["#FFEDD5", "#C2410C"],
  1: ["#FEE2E2", "#DC2626"],
};

const RESPONSIBLE_STYLE: Record<Responsible, { bg: string; text: string; dot: string; initials: string }> = {
  "Аня Г.":      { bg: "#FEFCE8", text: "#713F12", dot: "#EAB308", initials: "АГ" },
  "Настя П.":    { bg: "#F0FDF4", text: "#14532D", dot: "#22C55E", initials: "НП" },
  "Саша Г.":     { bg: "#EFF6FF", text: "#1E3A8A", dot: "#3B82F6", initials: "СГ" },
  "Таня К.":     { bg: "#FFF7ED", text: "#7C2D12", dot: "#F97316", initials: "ТК" },
  "Не назначен": { bg: "#F9FAFB", text: "#374151", dot: "#9CA3AF", initials: "?" },
};

const RESPONSIBLE_TAG_COLORS: Record<Responsible, [string, string]> = {
  "Аня Г.":      ["#FEF9C3", "#713F12"],
  "Настя П.":    ["#DCFCE7", "#14532D"],
  "Саша Г.":     ["#DBEAFE", "#1E3A8A"],
  "Таня К.":     ["#FFEDD5", "#7C2D12"],
  "Не назначен": ["#F3F4F6", "#6B7280"],
};

// ─── Data ─────────────────────────────────────────────────────────────────────

const KEY_TASKS: Task[] = [
  { ticket: "ANA-142", name: "Анализ конверсии воронки продаж Q2",  client: "Сбер",       direction: "Маркетинг",          status: "В работе",    priority: 3, time: "3д 2ч", comment: "Жду данные из CRM",       responsible: "Аня Г."      },
  { ticket: "ANA-138", name: "Сегментация клиентской базы по LTV",  client: "Яндекс",     direction: "Аналитика продаж",   status: "В работе",    priority: 4, time: "1д 6ч", comment: "Финальные правки",         responsible: "Аня Г."      },
  { ticket: "ANA-145", name: "Когортный анализ возвратов",           client: "Озон",       direction: "Операции",           status: "Ожидание",    priority: 2, time: "5д 0ч", comment: "Нет доступа к БД",        responsible: "Аня Г."      },
  { ticket: null,      name: "Анализ UX-воронки онбординга",         client: "Сбер",       direction: "Продукт",            status: "Согласование",priority: 3, time: "2д 3ч", comment: "На согласовании у PM",    responsible: "Аня Г."      },
  { ticket: "ANA-139", name: "Дашборд ключевых метрик ритейла",     client: "ВТБ",        direction: "BI",                 status: "В работе",    priority: 4, time: "2д 1ч", comment: "Финальные правки",         responsible: "Настя П."    },
  { ticket: "ANA-133", name: "A/B тест результатов email-рассылки", client: "МТС",        direction: "Маркетинг",          status: "Ожидание",    priority: 3, time: "4д 2ч", comment: "Жду данных от команды",   responsible: "Настя П."    },
  { ticket: null,      name: "Финансовый отчёт Q2 2026",            client: "Газпром",    direction: "Финансы",            status: "На паузе",    priority: 1, time: "8д 4ч", comment: "Заморожено",              responsible: "Настя П."    },
  { ticket: "ANA-147", name: "Прогноз продаж на H2 2026",           client: "МегаФон",    direction: "Аналитика продаж",   status: "В работе",    priority: 4, time: "1д 5ч", comment: "ML-модель готова",        responsible: "Саша Г."     },
  { ticket: "ANA-141", name: "Ценовая эластичность сегментов",       client: "Яндекс",     direction: "Ценообразование",    status: "Согласование",priority: 2, time: "6д 3ч", comment: "Правки по модели",        responsible: "Саша Г."     },
  { ticket: "ANA-150", name: "Визуализация клиентского пути",        client: "Сбер",       direction: "CX/Клиентский опыт", status: "В работе",    priority: 3, time: "0д 4ч", comment: "—",                       responsible: "Саша Г."     },
  { ticket: "ANA-136", name: "Анализ оттока клиентов",               client: "Тинькофф",   direction: "Аналитика продаж",   status: "В работе",    priority: 3, time: "3д 0ч", comment: "Готово, жду QA",          responsible: "Таня К."     },
  { ticket: null,      name: "Отчёт по NPS за июнь 2026",            client: "МТС",        direction: "CX/Клиентский опыт", status: "На паузе",    priority: 2, time: "7д 1ч", comment: "Перенесён",               responsible: "Таня К."     },
  { ticket: "ANA-148", name: "Аудит метрик мобильного приложения",  client: "Внутренний",  direction: "BI",                status: "Ожидание",    priority: 2, time: "1д 2ч", comment: "Нет владельца",           responsible: "Не назначен" },
  { ticket: null,      name: "Исследование рынка EdTech",             client: "Внутренний",  direction: "Стратегия",         status: "Ожидание",    priority: 1, time: "0д 0ч", comment: "Не начато",               responsible: "Не назначен" },
];

const QUEUE_TASKS: Task[] = [
  { ticket: "ANA-151", name: "Анализ эффективности промоакций",     client: "Озон",      direction: "Маркетинг",      status: "Ожидание", priority: 3, time: "—", comment: "Растёт приоритет",  responsible: "Аня Г."      },
  { ticket: "ANA-152", name: "Поведение новых пользователей",        client: "Сбер",      direction: "Продукт",        status: "Ожидание", priority: 4, time: "—", comment: "Срочно",            responsible: "Не назначен" },
  { ticket: "ANA-153", name: "Сравнительный анализ конкурентов",    client: "Яндекс",    direction: "Стратегия",      status: "Ожидание", priority: 2, time: "—", comment: "—",                 responsible: "Настя П."    },
  { ticket: null,      name: "Оценка ROI рекламных каналов",         client: "ВТБ",       direction: "Маркетинг",      status: "Ожидание", priority: 3, time: "—", comment: "Нужен доступ",      responsible: "Таня К."     },
  { ticket: "ANA-154", name: "Мониторинг качества данных",           client: "МегаФон",   direction: "Операции",       status: "Ожидание", priority: 2, time: "—", comment: "—",                 responsible: "Саша Г."     },
];

const RESPONSIBLE_ORDER: Responsible[] = ["Аня Г.", "Настя П.", "Саша Г.", "Таня К.", "Не назначен"];
const TABS = ["Актуальные", "Бэклог", "Готовые и стоп", "Все"];

// ─── Shared atoms ─────────────────────────────────────────────────────────────

function PriorityBadge({ priority }: { priority: Priority }) {
  const [bg, color] = PRIORITY_COLOR[priority];
  return (
    <span
      className="inline-flex items-center justify-center w-[22px] h-[22px] rounded text-[11px] font-semibold flex-shrink-0"
      style={{ backgroundColor: bg, color }}
    >
      {priority}
    </span>
  );
}

// Colorful tag — used only in filter dropdowns
function ColorTag({ value }: { value: string }) {
  const [bg, color] = TAG_COLORS[value] ?? ["#F3F4F6", "#6B7280"];
  return (
    <span
      className="inline-flex items-center px-1.5 py-0.5 rounded text-[11px] font-medium leading-tight whitespace-nowrap"
      style={{ backgroundColor: bg, color }}
    >
      {value}
    </span>
  );
}

// Responsible tag — used only in filter dropdown + queue table
function ResponsibleTag({ responsible }: { responsible: Responsible }) {
  const [bg, color] = RESPONSIBLE_TAG_COLORS[responsible];
  const s = RESPONSIBLE_STYLE[responsible];
  return (
    <span
      className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[11px] font-medium whitespace-nowrap"
      style={{ backgroundColor: bg, color }}
    >
      <span className="inline-block w-1.5 h-1.5 rounded-full flex-shrink-0" style={{ backgroundColor: s.dot }} />
      {responsible}
    </span>
  );
}

// Muted meta text — for all secondary fields in table cells
function Meta({ children }: { children: React.ReactNode }) {
  return <span className="text-[11px] text-[#AEAEB2] leading-none">{children}</span>;
}

// Ticket link / missing
function TicketMeta({ ticket }: { ticket: string | null }) {
  if (ticket) {
    return (
      <a
        href="#"
        onClick={e => e.preventDefault()}
        className="text-[11px] font-mono text-[#2563EB] hover:underline underline-offset-2 tracking-tight"
      >
        {ticket}
      </a>
    );
  }
  return <span className="text-[11px] text-[#DC2626] font-medium">нет тикета</span>;
}

// Group header row
function GroupHeaderRow({ responsible, count, colSpan }: { responsible: Responsible; count: number; colSpan: number }) {
  const s = RESPONSIBLE_STYLE[responsible];
  const label = count === 1 ? "задача" : count < 5 ? "задачи" : "задач";
  return (
    <tr>
      <td
        colSpan={colSpan}
        className="px-4 py-2 border-b border-t border-[rgba(0,0,0,0.06)]"
        style={{ backgroundColor: s.bg }}
      >
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span
              className="inline-flex items-center justify-center w-[22px] h-[22px] rounded-full text-[10px] font-semibold"
              style={{ backgroundColor: s.dot + "28", color: s.dot }}
            >
              {s.initials[0]}
            </span>
            <span className="text-[13px] font-semibold" style={{ color: s.text }}>
              {responsible}
            </span>
          </div>
          <span
            className="text-[11px] px-2 py-0.5 rounded-full font-medium"
            style={{ backgroundColor: s.dot + "1A", color: s.text }}
          >
            {count} {label}
          </span>
        </div>
      </td>
    </tr>
  );
}

function TH({ children, className = "" }: { children: React.ReactNode; className?: string }) {
  return (
    <th className={`px-4 py-2 text-left text-[10px] font-semibold text-[#AEAEB2] uppercase tracking-wider border-b border-[rgba(0,0,0,0.07)] bg-white whitespace-nowrap ${className}`}>
      {children}
    </th>
  );
}

function TD({ children, className = "" }: { children: React.ReactNode; className?: string }) {
  return (
    <td className={`px-4 py-2.5 border-b border-[rgba(0,0,0,0.05)] align-middle ${className}`}>
      {children}
    </td>
  );
}

// ─── Multi-select Dropdown ────────────────────────────────────────────────────

interface MultiSelectProps {
  label: string;
  options: string[];
  selected: Set<string>;
  onChange: (next: Set<string>) => void;
  renderOption?: (value: string) => React.ReactNode;
}

function MultiSelect({ label, options, selected, onChange, renderOption }: MultiSelectProps) {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function onDown(e: MouseEvent) {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    }
    document.addEventListener("mousedown", onDown);
    return () => document.removeEventListener("mousedown", onDown);
  }, []);

  const allSelected = selected.size === options.length;

  function toggle(v: string) {
    const next = new Set(selected);
    next.has(v) ? next.delete(v) : next.add(v);
    onChange(next);
  }

  const missing = options.filter(o => !selected.has(o));
  let btnLabel: string;
  if (allSelected)          btnLabel = label;
  else if (selected.size === 0) btnLabel = `${label}: ничего`;
  else if (missing.length <= 2) btnLabel = `${label}: кроме ${missing.join(", ")}`;
  else if (selected.size <= 2)  btnLabel = `${label}: ${[...selected].join(", ")}`;
  else                          btnLabel = `${label}: ${[...selected][0]} +${selected.size - 1}`;

  return (
    <div ref={ref} className="relative">
      <button
        onClick={() => setOpen(o => !o)}
        className={[
          "flex items-center gap-1.5 px-3 py-[7px] text-[13px] border rounded-[6px] transition-colors whitespace-nowrap leading-none",
          allSelected
            ? "bg-white border-[rgba(0,0,0,0.1)] text-[#3C3C43] hover:bg-[#F5F5F7]"
            : "bg-[#EFF6FF] border-[#BFDBFE] text-[#1D4ED8] hover:bg-[#DBEAFE]",
          open ? "ring-1 ring-[rgba(0,0,0,0.12)]" : "",
        ].join(" ")}
      >
        <span className="max-w-[200px] truncate">{btnLabel}</span>
        <ChevronDown size={12} className={`flex-shrink-0 opacity-60 transition-transform ${open ? "rotate-180" : ""}`} />
      </button>

      {open && (
        <div className="absolute top-[calc(100%+4px)] left-0 bg-white border border-[rgba(0,0,0,0.1)] rounded-[8px] shadow-[0_4px_20px_rgba(0,0,0,0.08)] z-50 min-w-[210px] py-1.5 max-h-[300px] overflow-y-auto">
          <button
            onClick={() => onChange(allSelected ? new Set() : new Set(options))}
            className="w-full flex items-center gap-2.5 px-3 py-1.5 text-[12px] text-[#6B7280] hover:bg-[#F5F5F7] transition-colors"
          >
            <Checkbox checked={allSelected} indeterminate={!allSelected && selected.size > 0} />
            <span className="font-medium">Выбрать все</span>
          </button>
          <div className="border-t border-[rgba(0,0,0,0.06)] my-1" />
          {options.map(opt => (
            <button
              key={opt}
              onClick={() => toggle(opt)}
              className="w-full flex items-center gap-2.5 px-3 py-1.5 hover:bg-[#F5F5F7] transition-colors text-left"
            >
              <Checkbox checked={selected.has(opt)} />
              {renderOption ? renderOption(opt) : <span className="text-[13px] text-[#1D1D1F]">{opt}</span>}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

function Checkbox({ checked, indeterminate }: { checked: boolean; indeterminate?: boolean }) {
  return (
    <span className={[
      "inline-flex items-center justify-center w-3.5 h-3.5 rounded border flex-shrink-0 transition-colors",
      checked || indeterminate ? "bg-[#2563EB] border-[#2563EB]" : "border-[#D1D5DB] bg-white",
    ].join(" ")}>
      {indeterminate && !checked
        ? <span className="block w-2 h-px bg-white" />
        : checked
        ? <Check size={9} className="text-white stroke-[2.5]" />
        : null}
    </span>
  );
}

// ─── App ──────────────────────────────────────────────────────────────────────

export default function App() {
  const [activeTab, setActiveTab] = useState("Актуальные");
  const [search, setSearch]       = useState("");

  const [selClients,     setSelClients]     = useState<Set<string>>(DEFAULT_CLIENTS);
  const [selDirections,  setSelDirections]  = useState<Set<string>>(DEFAULT_DIRECTIONS);
  const [selStatuses,    setSelStatuses]    = useState<Set<string>>(DEFAULT_STATUSES);
  const [selResponsibles,setSelResponsibles]= useState<Set<string>>(DEFAULT_RESPONSIBLES);

  const filtersChanged =
    selClients.size      !== DEFAULT_CLIENTS.size     ||
    selDirections.size   !== DEFAULT_DIRECTIONS.size  ||
    selStatuses.size     !== DEFAULT_STATUSES.size    ||
    selResponsibles.size !== DEFAULT_RESPONSIBLES.size||
    search !== "";

  function resetFilters() {
    setSelClients(new Set(DEFAULT_CLIENTS));
    setSelDirections(new Set(DEFAULT_DIRECTIONS));
    setSelStatuses(new Set(DEFAULT_STATUSES));
    setSelResponsibles(new Set(DEFAULT_RESPONSIBLES));
    setSearch("");
  }

  function applyFilters(tasks: Task[]) {
    return tasks.filter(t => {
      if (search.trim()) {
        const q = search.toLowerCase();
        const hit =
          (t.ticket?.toLowerCase().includes(q)) ||
          t.name.toLowerCase().includes(q) ||
          t.comment.toLowerCase().includes(q);
        if (!hit) return false;
      }
      return (
        selClients.has(t.client) &&
        selDirections.has(t.direction) &&
        selStatuses.has(t.status) &&
        selResponsibles.has(t.responsible)
      );
    });
  }

  const filteredKey   = useMemo(() => applyFilters(KEY_TASKS),   [search, selClients, selDirections, selStatuses, selResponsibles]);
  const filteredQueue = useMemo(() => applyFilters(QUEUE_TASKS), [search, selClients, selDirections, selStatuses, selResponsibles]);

  const groups = useMemo(
    () => RESPONSIBLE_ORDER
      .map(r => ({ responsible: r, tasks: filteredKey.filter(t => t.responsible === r) }))
      .filter(g => g.tasks.length > 0),
    [filteredKey]
  );

  return (
    <div
      className="min-h-screen bg-[#F5F5F7]"
      style={{ fontFamily: "'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', system-ui, sans-serif" }}
    >
      {/* Header */}
      <header className="bg-[#F5F5F7] border-b border-[rgba(0,0,0,0.08)]">
        <div className="max-w-[1440px] mx-auto px-6 md:px-10 py-4 flex items-center justify-between gap-4">
          <h1 className="text-[16px] font-semibold text-[#1D1D1F] tracking-[-0.015em]">
            Задачи в аналитике на текущую неделю
          </h1>
          <span className="text-[12px] text-[#AEAEB2] whitespace-nowrap flex-shrink-0">Обновлено: 09 июля 26</span>
        </div>
      </header>

      {/* Tabs */}
      <div className="bg-[#EBEBED] border-b border-[rgba(0,0,0,0.1)]">
        <div className="max-w-[1440px] mx-auto flex">
          {TABS.map(tab => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={[
                "flex-1 py-2.5 text-[13px] font-medium transition-colors border-r border-[rgba(0,0,0,0.06)] last:border-r-0",
                activeTab === tab ? "bg-white text-[#1D1D1F]" : "text-[#6B6B70] hover:text-[#1D1D1F] hover:bg-[#E0E0E2]",
              ].join(" ")}
            >
              {tab}
            </button>
          ))}
        </div>
      </div>

      {/* Search */}
      <div className="bg-white border-b border-[rgba(0,0,0,0.08)]">
        <div className="max-w-[1440px] mx-auto px-6 md:px-10 py-3">
          <div className="relative">
            <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#AEAEB2] pointer-events-none" />
            <input
              type="text"
              placeholder="Тикет, название, комментарий…"
              value={search}
              onChange={e => setSearch(e.target.value)}
              className="w-full pl-8 pr-8 py-2 text-[13px] bg-[#F5F5F7] border border-[rgba(0,0,0,0.08)] rounded-[7px] outline-none focus:border-[rgba(0,0,0,0.18)] placeholder:text-[#AEAEB2] text-[#1D1D1F] transition-colors"
            />
            {search && (
              <button onClick={() => setSearch("")} className="absolute right-3 top-1/2 -translate-y-1/2 text-[#AEAEB2] hover:text-[#1D1D1F] text-base leading-none transition-colors">
                ×
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Filters */}
      <div className="bg-white border-b border-[rgba(0,0,0,0.08)]">
        <div className="max-w-[1440px] mx-auto px-6 md:px-10 py-3 flex items-center gap-2 flex-wrap">
          <MultiSelect label="Заказчик"          options={ALL_CLIENTS}      selected={selClients}      onChange={setSelClients}      renderOption={opt => <ColorTag value={opt} />} />
          <MultiSelect label="Ответственный"     options={ALL_RESPONSIBLES} selected={selResponsibles} onChange={setSelResponsibles} renderOption={opt => <ResponsibleTag responsible={opt as Responsible} />} />
          <MultiSelect label="К чему относится"  options={ALL_DIRECTIONS}   selected={selDirections}   onChange={setSelDirections}   renderOption={opt => <ColorTag value={opt} />} />
          <MultiSelect label="Статус"            options={ALL_STATUSES}     selected={selStatuses}     onChange={setSelStatuses}     renderOption={opt => <ColorTag value={opt} />} />
          <div className="flex-1" />
          {filtersChanged && (
            <button onClick={resetFilters} className="px-3 py-[7px] text-[13px] text-[#2563EB] hover:text-[#1D4ED8] font-medium transition-colors leading-none">
              Сбросить
            </button>
          )}
        </div>
      </div>

      {/* Content */}
      <div className="max-w-[1440px] mx-auto px-6 md:px-10 py-6 space-y-8">

        {/* ── Section 1: Key tasks ── */}
        <section>
          <h2 className="text-[13px] font-semibold text-[#1D1D1F] mb-3 tracking-[-0.01em] uppercase text-[#AEAEB2] tracking-wider">
            Ключевые задачи по ответственным
          </h2>
          <div className="rounded-[8px] border border-[rgba(0,0,0,0.09)] bg-white overflow-hidden overflow-x-auto">
            <table className="w-full border-collapse" style={{ tableLayout: "fixed", minWidth: "960px" }}>
              <colgroup>
                {/* Тикет | Название | Заказчик | К чему | Статус | Приоритет | Время | Комментарий */}
                <col style={{ width: "92px" }} />
                <col />
                <col style={{ width: "100px" }} />
                <col style={{ width: "148px" }} />
                <col style={{ width: "110px" }} />
                <col style={{ width: "80px" }} />
                <col style={{ width: "86px" }} />
                <col style={{ width: "200px" }} />
              </colgroup>
              <thead>
                <tr>
                  <TH>Тикет</TH>
                  <TH>Название</TH>
                  <TH>Заказчик</TH>
                  <TH>К чему относится</TH>
                  <TH>Статус</TH>
                  <TH className="text-center">Приоритет</TH>
                  <TH>Время</TH>
                  <TH>Комментарий</TH>
                </tr>
              </thead>
              <tbody>
                {groups.map(({ responsible, tasks }) => (
                  <React.Fragment key={responsible}>
                    <GroupHeaderRow responsible={responsible} count={tasks.length} colSpan={8} />
                    {tasks.map((task, i) => (
                      <tr key={`${responsible}-${i}`} className="hover:bg-[#F9F9FB] transition-colors">
                        <TD><TicketMeta ticket={task.ticket} /></TD>
                        <TD>
                          <span className="text-[14px] font-medium text-[#1D1D1F] leading-snug tracking-[-0.01em]">
                            {task.name}
                          </span>
                        </TD>
                        <TD><Meta>{task.client}</Meta></TD>
                        <TD><Meta>{task.direction}</Meta></TD>
                        <TD><Meta>{task.status}</Meta></TD>
                        <TD className="text-center">
                          <PriorityBadge priority={task.priority} />
                        </TD>
                        <TD><span className="text-[11px] font-mono text-[#AEAEB2]">{task.time}</span></TD>
                        <TD>
                          {task.comment && task.comment !== "—"
                            ? <Meta>{task.comment}</Meta>
                            : <span className="text-[11px] text-[#D1D1D6]">—</span>}
                        </TD>
                      </tr>
                    ))}
                  </React.Fragment>
                ))}
                {groups.length === 0 && (
                  <tr>
                    <td colSpan={8} className="px-4 py-10 text-center text-[13px] text-[#AEAEB2]">
                      Задачи не найдены — попробуйте изменить фильтры
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </section>

        {/* ── Section 2: Queue ── */}
        <section>
          <h2 className="text-[13px] font-semibold uppercase text-[#AEAEB2] tracking-wider mb-3">
            Задачи в очереди
          </h2>
          <div className="rounded-[8px] border border-[rgba(0,0,0,0.09)] bg-white overflow-hidden overflow-x-auto">
            <table className="w-full border-collapse" style={{ tableLayout: "fixed", minWidth: "1040px" }}>
              <colgroup>
                {/* Тикет | Название | Заказчик | К чему | Статус | Приоритет | Время | Ответственный | Комментарий */}
                <col style={{ width: "92px" }} />
                <col />
                <col style={{ width: "100px" }} />
                <col style={{ width: "148px" }} />
                <col style={{ width: "110px" }} />
                <col style={{ width: "80px" }} />
                <col style={{ width: "86px" }} />
                <col style={{ width: "120px" }} />
                <col style={{ width: "180px" }} />
              </colgroup>
              <thead>
                <tr>
                  <TH>Тикет</TH>
                  <TH>Название</TH>
                  <TH>Заказчик</TH>
                  <TH>К чему относится</TH>
                  <TH>Статус</TH>
                  <TH className="text-center">Приоритет</TH>
                  <TH>Время</TH>
                  <TH>Ответственный</TH>
                  <TH>Комментарий</TH>
                </tr>
              </thead>
              <tbody>
                {filteredQueue.map((task, i) => (
                  <tr key={i} className="hover:bg-[#F9F9FB] transition-colors">
                    <TD><TicketMeta ticket={task.ticket} /></TD>
                    <TD>
                      <span className="text-[14px] font-medium text-[#1D1D1F] leading-snug tracking-[-0.01em]">
                        {task.name}
                      </span>
                    </TD>
                    <TD><Meta>{task.client}</Meta></TD>
                    <TD><Meta>{task.direction}</Meta></TD>
                    <TD><Meta>{task.status}</Meta></TD>
                    <TD className="text-center">
                      <PriorityBadge priority={task.priority} />
                    </TD>
                    <TD><span className="text-[11px] font-mono text-[#AEAEB2]">{task.time}</span></TD>
                    <TD><ResponsibleTag responsible={task.responsible} /></TD>
                    <TD>
                      {task.comment && task.comment !== "—"
                        ? <Meta>{task.comment}</Meta>
                        : <span className="text-[11px] text-[#D1D1D6]">—</span>}
                    </TD>
                  </tr>
                ))}
                {filteredQueue.length === 0 && (
                  <tr>
                    <td colSpan={9} className="px-4 py-10 text-center text-[13px] text-[#AEAEB2]">
                      Задачи не найдены — попробуйте изменить фильтры
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </section>

        <div className="pb-2 text-center text-[11px] text-[#D1D1D6]">
          Аналитика · Неделя 28, 2026
        </div>
      </div>
    </div>
  );
}
